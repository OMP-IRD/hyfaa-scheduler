# Configuration 

+ Niger
+ GSMAP from 2017/04/01 to 2021/02/16
+ empty assimilation database


