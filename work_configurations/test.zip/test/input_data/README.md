# Niger static data and default hydrological state start

+ `static_data.nc` contains mesh and climatology for Niger
+ `default_start_hydrostate.nc` contains default configuration : the result of a 1200 days simulation starting 01/01/2011 and ending 15/04/2014. This helps initialize the model faster.
