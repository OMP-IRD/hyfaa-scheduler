--------------------------------------------------------------------------------
				HYFAA TUTORIAL
--------------------------------------------------------------------------------

Run Hyfaa exemple:
	- Comment/uncomment output expectation: run.py
	- run simulation: ./run_pbs.py --pbs_name name_simu (CNES or PBS) else launch ./run.sh
	- plot output : python extarct_plot_hyfaa.py s-e-a station.txt (see -h for help/options/arguments definitions)

----------------------------------------
Some changes exemples according to simulation expectations: 
----------------------------------------

EX-1: Create MGBstandard 
	On config/input_mgbstandard_solution.yaml :
		- activate assimilation: false
		- perturb_static_data: false
		- n_ensemble = 1

EX-2 : Create ensemblist solution with rainfall perturbation (e.g: config/input_ensemblist_solution.yaml)
	On config/input_ensemblist_solution.yaml :
		- activate assimilation : false
		- perturb_static_data: false
		- n_ensemble = n (n= ensemble number)

EX-3 : Create ensemblist solution with rainfall perturbation AND parameters perturbation
        On config/input_ensemblist_solution.yaml :
		- activate assimilation: false
		- perturb_static_data: true
		- n_ensemble = n 
		- change min/max (= values) for each varying_parameters (river_width/river_depth/manning) 

EX-4: Create ensemblist solution with rainfall perturbation AND river_depth perturbation
        On config/input_ensemblist_solution.yaml :	
		- activate assimilation: false
		- perturb_static_data: true
		- n_ensemble = n
		- change min/max (= values) for each river_depth
	On config/assimilation_parameters.yaml : 
		- manning_coefficient: false
		- river_width: false
		- river_depth: true
		WARNING: always discharge perturbation

EX-5: Create assimilated solution into EX-2 (e.g: config/input_assimilated_solution.yaml)
        On config/input_assimilated_solution.yaml :
		- activate assimilation : true
		- perturb_static_data: false
		- n_ensemble = n (n= ensemble number)

EX-6: Create MGBstandard since 2020-01-01
        On config/input_mgbstandard_solution.yaml :
		- EX-1 parametrisation
		- time_start: '2020-01-01T00:00:00.000000'

EX-7: Create MGBstandard for other watershed
	On config/input_ensemblist_solution.yaml :
		- EX-1 parametrisation 
		- change forcing_grid_geo_selection: lonmin/lonmax/latmin/latmax
	On databases/* :
		- Create new rainfall data for each mesh
	On input_data/static_data.nc :
		- Create new static_data according to watershed mgb preprocessing (mesh/climatology/lulc/soil data)	
	(see mgb2hyfaa.py to convert input MGB to input HYFAA - rainfall + static_data)
