#!/usr/bin/env python
# encoding: utf-8
""" Extract output data from HYFAA
    and plot it

    Created by Laetitia Gal on 2021-07-01
    Copyright (c) 2021 CNES/Legos/CTOH./Ocean-Next All rights reserved
"""

import numpy as np
import argparse
import netCDF4
import sys
from math import ceil
import os
import glob
import matplotlib.pyplot as plt
import datetime as dt
from datetime import timedelta

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Extract output HYFAA data and plot it\n",
                                     formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("dtype",
                        help="type of data. Default is 'e-s-a', where: \n"
                        "e= ensemblist\n"
                        "s= mgbstandard\n"
                        "a= assimilated\n")
    parser.add_argument("vs",
                        help="virtual station to extract [txt file with Mini & Name]")
    parser.add_argument('-s', "--startDT",default=None,
                        help="Start datetime to extract [default=None]")
    parser.add_argument('-e',"--endDT",default=None,
                        help="End datetime to extract [default=None]")
    parser.add_argument("-v", "--nvar",default="streamflow_catchment",
                        help="variable name [default=streamflow_catchment]")
    parser.add_argument('-t','--otype', default='control',
                        help='type of analysis ["control" (default) or "analysis"]')
    parser.add_argument('-ot','--outtype', default='daily',
                        help='type of output file to read ["daily" (default) or "summary"]')
    parser.add_argument("-o", "--outfile",default="plot_minis",
                        help="Name of plot [default='plot_minis' {_{nvar}.png}]")
    parser.add_argument("-d", "--dyn",default="True",
                        help="Plot dynamics plots [True (default) or False]")

    args = parser.parse_args()

    # ------ CONVERT ARGS 2 VARIABLES ------
    dtype = args.dtype
    nvar = args.nvar
    startDT= args.startDT
    endDT= args.endDT
    otype = args.otype
    vs = args.vs
    out = args.outtype
    outfile=args.outfile


    # Read Stations file
    mini =read_miniS(vs)

    # ------ PATH ---------
    egtyp= dtype.split('-')[0]
    if egtyp =='e':
        egtyp_name = 'ensemblist'
    if egtyp =='s':
        egtyp_name='mgbstandard'
    if egtyp == 'a':
        egtyp_name='assimilated'
    path= egtyp_name+'_solution_databases/hydrological_states_db/data_store/'+otype+'/'

    # ------ DATES ---------
    first_datei=sorted(os.listdir(path))[0].split('_')[1]
    datei_f = first_datei[0:4]+'-'+first_datei[4:6]+'-'+first_datei[6:8]
    datei_f = strdate2date(datei_f)

    first_datef=sorted(os.listdir(path))[len(os.listdir(path))-1].split('_')[1]
    datef_f = first_datef[0:4]+'-'+first_datef[4:6]+'-'+first_datef[6:8]
    datef_f = strdate2date(datef_f)

    if startDT is not None:
        datei = strdate2date(startDT)
    else:
        datei = datei_f
    if endDT is not None:
        datef = strdate2date(endDT)
    else:
        datef = datef_f

    #control
    if datei < datei_f :
        print(" [startDT = "+str(datei)+"  //  1stDT = "+str(datei_f))
        sys.exit("error -- start date > first date of simu")
    if datef > datef_f :
        print(" [endDT = "+str(datef)+"  //  lastDT = "+str(datef_f))
        sys.exit("error -- end date > last date of simu")

    period = (datef - datei).days+1
    all_dates = [datei+timedelta(days=x) for x in range((datef-datei).days+1)]

    # ------ READ OUTPUT DATA ---------
    print('--------- Extract data -------')
    vmean, vmin, vmax = [], [], []
    types= dtype.split('-')
    for typ in types:
        if typ =='e': typ_name = 'ensemblist'
        if typ =='s': typ_name='mgbstandard'
        if typ == 'a': typ_name='assimilated'

        direc= typ_name+'_solution_databases/hydrological_states_db/data_store/'+otype+'/'
        ref = netCDF4.Dataset(direc+os.listdir(direc)[0],'r')
        nens = ref.dimensions['n_ensemble'].size
        ncells = ref.dimensions['n_meshes'].size
        if out == 'daily':
            var_mean, var_min, var_max=read_daily_nc(mini['mini'], period, nens, datei, direc, nvar)
        if out == 'summary':
            var_mean, var_min, var_max=read_summary_nc(mini['mini'], nvar, typ_name, datei, datef)
        print(' '+typ_name+' --- done')
        vmean.append(np.array(var_mean, dtype={'names':[typ], 'formats':[np.float]}))
        vmin.append(np.array(var_min, dtype={'names':[typ], 'formats':[np.float]}))
        vmax.append(np.array(var_max, dtype={'names':[typ], 'formats':[np.float]}))


    print('--------- Plot -------')
    plot_mgb_mini(mini, all_dates, vmean, vmax, vmin, (outfile+'_'+dtype+'_'+
                                                       nvar+'_'+out+'.png'))
    if args.dyn == 'True':
        plot_dyn(mini, all_dates, vmean, vmax, vmin, dtype)

def strdate2date(strdate):
    s=strdate.split('-')
    y, m, d = s[0], s[1], s[2]
    date = dt.datetime(int(y), int(m), int(d), 0, 0)
    return(date)

def read_daily_nc(lst_mini, period, nens, date, path, nvar):
    minis = lst_mini
    var=np.full((len(minis),period,nens),None)
    for d in range(period):
        loadingBar(d+1, period, 4)
        str_date = date.strftime('%Y%m%dT%H%M%S')
        file = [os.path.basename(x) for x in
                glob.glob(os.path.join(path,'DATA_'+str_date+'*'))][0]
        nc = netCDF4.Dataset(path+file,'r')

        for ensid in range(nens):
            v=nc.variables[nvar+'_'+str(ensid)][:]
            for (i,j) in enumerate(minis):
                var[i,d,ensid]=v[j-1]
        date += dt.timedelta(days=1)
    var_min=np.nanmin(var,axis=2)
    var_max=np.nanmax(var,axis=2)
    var_mean=np.nanmean(var,axis=2)
    return(var_mean,var_min, var_max)

def read_summary_nc(lst_mini, nvar, typ_name, datei, datef):
    minis = lst_mini
    summ=netCDF4.Dataset(typ_name+'_solution_databases/post_processing_portal.nc', 'r')
    time = np.array(summ.variables['time'][:])
    date = np.array([dt.datetime(1950, 1, 1, 0, 0, 0) +
                     dt.timedelta(days=i) for i in time])
    ind_start = int(np.where(date == datei)[0])
    ind_end = int(np.where(date == datef)[0])+1
    nens = summ.dimensions['n_ensemble'].size
    var_mean, var_min, var_max=[],[],[]
    for index, mini in enumerate(minis):
        loadingBar(index+1, len(minis), 4)
        mean = np.array(summ.variables[nvar+'_mean'][:])[ind_start:ind_end]
        var_mean.append(mean[:,mini-1])
        if nens > 1:
            std = np.array(summ.variables[nvar+'_std'][:])[ind_start:ind_end]
            var_min.append(mean[:,mini-1]-std[:,mini-1])
            var_max.append(mean[:,mini-1]+std[:,mini-1])
        else:
            var_min.append(np.repeat(0,len(mean)))
            var_max.append(np.repeat(0,len(mean)))
    return(var_mean, var_min, var_max)

def read_miniS(filename, skiprows=0):
    name = ['mini', 'station']
    fmt = ['i4', 'U30']
    dtype= list(zip(name, fmt))
    data = np.loadtxt(filename, dtype=dtype, skiprows=skiprows)
    return(data)

def plot_dyn(mini, dates, vmean, vmin, vmax, dtype):
    import plotly.graph_objects as go
    try:
        os.makedirs("plotD_"+dtype)
    except FileExistsError:
        pass
    for index, st in enumerate(mini['mini']):
        fig = go.Figure()
        for  d in range(len(vmean)):
            if np.array(vmean[d]).dtype.names[0] == 'e':
                typ_name = 'ensemblist'
                color = "black"
                fillcolor= 'rgba(0,0,0,0.2)'
            if np.array(vmean[d]).dtype.names[0] == 's':
                typ_name='mgbstandard'
                color = "red"
                fillcolor= 'rgba(0,0,0,0)'
            if np.array(vmean[d]).dtype.names[0] == 'a':
                typ_name='assimilated'
                color = "green"
                fillcolor= 'rgba(26,150,65,0.2)'
            x = dates
            mean = np.array(vmean[d][index], dtype=float)
            upper = np.array(vmax[d][index], dtype=float)
            lower = np.array(vmin[d][index], dtype=float)
            fig.add_traces(go.Scatter(x=x, y = mean,
                                      name=typ_name,
                                      line = dict(color = color)))
            fig.add_traces(go.Scatter(x=x, y = lower,
                                      showlegend=False,
                                      line = dict(color='rgba(0,0,0,0)')))
            fig.add_traces(go.Scatter(x=x, y = upper,
                                      fill='tonexty',
                                      fillcolor=fillcolor,
                                      mode='none',
                                      showlegend=False))
            fig.update_layout(title_text=mini['station'][index]+' ['+str(st)+']')
            fig.update_layout(xaxis=dict(rangeslider=dict(visible=True),type="date"))
            fig.write_html('plotD_'+dtype+'/plotD_'+mini['station'][index]+'.html')
    return(fig)

def plot_mgb_mini(mini, dates, vmean, vmin, vmax, output):
    fig = plt.figure()
    nrow = ceil(len(mini)/3)
    #fig = plt.gcf()
    fig.set_size_inches(nrow*15, nrow*5)
    #manager = plt.get_current_fig_manager()
    #manager.window.showMaximized()
    for index, st in enumerate(mini['mini']):
        ax = fig.add_subplot(nrow,3,index+1)
        for d in range(len(vmean)):
            if np.array(vmean[d]).dtype.names[0] == 'e':
                typ_name = 'ensemblist'
                color = "black"
            if np.array(vmean[d]).dtype.names[0] == 's':
                typ_name='mgbstandard'
                color = "red"
            if np.array(vmean[d]).dtype.names[0] == 'a':
                typ_name='assimilated'
                color = "green"
            x = dates
            mean = np.array(vmean[d][index], dtype=float)
            upper = np.array(vmax[d][index], dtype=float)
            lower = np.array(vmin[d][index], dtype=float)
            ax.plot(x, mean, color = color, label = typ_name)
            ax.fill_between(x, upper, lower, alpha=.2, color=color, label='')
        ax.set_ylabel('Discharge [m3/s]', fontsize='large')
        ax.set_title(mini['station'][index]+' ['+str(st)+']', fontsize=10)
    ax.legend(frameon=False, loc='upper center', ncol=2)
    fig.savefig(output, dpi=100)
    return(fig.show())

def loadingBar(count,total,size):
    percent = float(count)/float(total)*100
    sys.stdout.write("\r" + str(int(count)).rjust(3,'0')+"/"+
                     str(int(total)).rjust(3,'0') + ' ['
                     + '='*int(percent/10)*size + ' '*(10-int(percent/10))*size
                     + ']')

if __name__ == '__main__':
    main()








